# Onlyme Android App — Prototype 0.1.0

A native Android Studio starter project for a clean white-and-blue Personal Life Manager.

## Included in this prototype
- Create account / log in (passwords are SHA-256 hashed locally)
- Separate locally stored task, note and transaction data per account
- Task completion toggle
- Income/expense totals and balance report
- Basic local Admin view (account count)
- Clean white-and-blue UI

## Important limitations
This is an early prototype, not a production-ready app. Accounts and data live only on the current device in SharedPreferences. There is no cloud backend, cross-device synchronization, password recovery, server-side admin, scheduled reminders, encryption-at-rest, or security review. Do not store sensitive or financial information in this prototype. For real multi-user use, add a backend such as Firebase Authentication + Firestore with security rules, and implement Android notification scheduling.

## Build an APK
1. Install Android Studio on a computer and let it install Android SDK 35 and a compatible JDK.
2. Open this `Onlyme` folder as an existing project.
3. Allow Gradle sync to complete (internet access is needed the first time).
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the output APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.onlyme.app`  
Minimum Android: 6.0 (API 23)  
Version: 0.1.0
