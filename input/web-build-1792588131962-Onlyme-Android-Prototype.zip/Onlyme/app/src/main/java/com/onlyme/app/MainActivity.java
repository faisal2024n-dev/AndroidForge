package com.onlyme.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.security.MessageDigest;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BLUE = Color.rgb(36,107,253), INK = Color.rgb(27,39,64), MUTED = Color.rgb(105,119,145), BG = Color.rgb(246,249,255), LINE = Color.rgb(226,233,245);
    private android.content.SharedPreferences prefs;
    private String user = "";
    private LinearLayout root, body;
    private String page = "Dashboard";

    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(Color.WHITE); getWindow().setNavigationBarColor(Color.WHITE); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); prefs=getSharedPreferences("onlyme_local",MODE_PRIVATE); user=prefs.getString("active_user",""); if(user.isEmpty()) showLogin(); else showApp(); }

    private String hash(String s) { try { byte[] d=MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8")); StringBuilder x=new StringBuilder(); for(byte a:d)x.append(String.format(Locale.US,"%02x",a)); return x.toString(); } catch(Exception e){return s;} }
    private JSONObject users(){ try{return new JSONObject(prefs.getString("users","{}"));}catch(Exception e){return new JSONObject();} }
    private void saveUsers(JSONObject j){prefs.edit().putString("users",j.toString()).apply();}
    private void showLogin(){
        root=base(); root.setGravity(Gravity.CENTER); root.setPadding(24,28,24,28);
        LinearLayout card=vertical(); card.setPadding(24,28,24,28); card.setBackground(round(Color.WHITE,22));
        TextView logo=text("onlyme",34,BLUE,true); logo.setGravity(Gravity.CENTER); card.addView(logo); TextView sub=text("Your personal life, in one place.",15,MUTED,false); sub.setGravity(Gravity.CENTER); addGap(card,8); card.addView(sub); addGap(card,28);
        EditText email=field("Email or username"); card.addView(email); addGap(card,12); EditText pass=field("Password"); pass.setInputType(129); card.addView(pass); addGap(card,18);
        Button login=button("Log in"); card.addView(login); addGap(card,8); Button signup=button("Create account"); signup.setBackground(round(Color.rgb(235,242,255),14)); signup.setTextColor(BLUE); card.addView(signup);
        TextView note=text("Prototype mode: accounts and data are stored on this device only.",12,MUTED,false); note.setGravity(Gravity.CENTER); addGap(card,18); card.addView(note); root.addView(card,new LinearLayout.LayoutParams(-1,-2));
        login.setOnClickListener(v->{String u=email.getText().toString().trim().toLowerCase(Locale.US),p=pass.getText().toString(); if(u.isEmpty()||p.isEmpty()){toast("Enter username and password");return;} JSONObject us=users(),rec=us.optJSONObject(u); if(rec!=null&&hash(p).equals(rec.optString("password"))){user=u;prefs.edit().putString("active_user",user).apply();showApp();}else toast("Account not found or password is incorrect");});
        signup.setOnClickListener(v->{String u=email.getText().toString().trim().toLowerCase(Locale.US),p=pass.getText().toString(); if(u.length()<3||p.length()<6){toast("Use a username/email and password with at least 6 characters");return;} JSONObject us=users();if(us.has(u)){toast("Account already exists");return;}try{JSONObject rec=new JSONObject();rec.put("password",hash(p));rec.put("created",System.currentTimeMillis());us.put(u,rec);saveUsers(us);user=u;prefs.edit().putString("active_user",user).apply();showApp();}catch(Exception e){toast("Could not create account");}});
    }

    private void showApp(){ root=base(); root.setPadding(0,0,0,0); LinearLayout top=vertical(); top.setPadding(20,16,20,14); top.setBackgroundColor(Color.WHITE); LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); TextView brand=text("onlyme",26,BLUE,true); head.addView(brand,new LinearLayout.LayoutParams(0,-2,1)); Button out=button("Log out"); out.setTextSize(12); out.setPadding(14,8,14,8); head.addView(out); top.addView(head); TextView hello=text("Personal Life Manager  ·  "+user,13,MUTED,false); top.addView(hello); root.addView(top); ScrollView sc=new ScrollView(this); body=vertical(); body.setPadding(18,18,18,24); sc.setFillViewport(true);sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); out.setOnClickListener(v->{prefs.edit().remove("active_user").apply();user="";showLogin();}); render(); }

    private void render(){ body.removeAllViews(); TextView title=text(page,27,INK,true); body.addView(title); TextView hint=text("A calmer way to organize your day.",14,MUTED,false); body.addView(hint); addGap(body,18);
        if(page.equals("Dashboard")){ JSONArray tasks=data("tasks"),notes=data("notes"),money=data("money"); int done=0;for(int i=0;i<tasks.length();i++)if(tasks.optJSONObject(i)!=null&&tasks.optJSONObject(i).optBoolean("done"))done++; gridStat("Tasks",String.valueOf(tasks.length()),"Completed: "+done);gridStat("Notes",String.valueOf(notes.length()),"Ideas and important details");gridStat("Transactions",String.valueOf(money.length()),"Income and expenses"); addGap(body,10); section("Quick actions"); action("＋  Add a task",()->addItem("tasks"));action("✎  Write a note",()->addItem("notes"));action("৳  Add income or expense",()->addItem("money"));action("◷  Reminders",()->new AlertDialog.Builder(this).setTitle("Reminders").setMessage("Reminder scheduling will be added in the next build. You can keep tasks here for now.").setPositiveButton("OK",null).show()); }
        else if(page.equals("Tasks")){listData("tasks"); Button add=button("+ Add task");body.addView(add);add.setOnClickListener(v->addItem("tasks"));}
        else if(page.equals("Notes")){listData("notes");Button add=button("+ New note");body.addView(add);add.setOnClickListener(v->addItem("notes"));}
        else if(page.equals("Income & Expenses")){listData("money");Button add=button("+ Add transaction");body.addView(add);add.setOnClickListener(v->addItem("money"));}
        else if(page.equals("Reports")){JSONArray t=data("tasks"),n=data("notes"),m=data("money");int done=0;double income=0,expense=0;for(int i=0;i<t.length();i++)if(t.optJSONObject(i)!=null&&t.optJSONObject(i).optBoolean("done"))done++;for(int i=0;i<m.length();i++){JSONObject o=m.optJSONObject(i);if(o!=null){double a=o.optDouble("amount");if(o.optString("type").equals("Income"))income+=a;else expense+=a;}}gridStat("Tasks completed",done+" / "+t.length(),"Across all saved tasks");gridStat("Total income",String.format(Locale.US,"%.2f",income),"Local currency amount");gridStat("Total expenses",String.format(Locale.US,"%.2f",expense),"Local currency amount");gridStat("Balance",String.format(Locale.US,"%.2f",income-expense),"Income minus expenses");}
        else if(page.equals("Admin")){JSONObject us=users();gridStat("Local accounts",String.valueOf(us.length()),"Accounts on this device");TextView warn=text("Admin is a basic prototype view. It does not provide remote user management or cloud security.",13,MUTED,false);addGap(body,8);body.addView(warn);}
        addGap(body,20); section("Navigate"); String[][] nav={{"Dashboard","⌂"},{"Tasks","✓"},{"Notes","✎"},{"Income & Expenses","৳"},{"Reports","▥"},{"Admin","⚙"}}; for(String[] a:nav){action(a[1]+"   "+a[0],()->{page=a[0];render();});}
    }
    private JSONArray data(String kind){try{return new JSONArray(prefs.getString("data_"+user+"_"+kind,"[]"));}catch(Exception e){return new JSONArray();}}
    private void saveData(String kind,JSONArray a){prefs.edit().putString("data_"+user+"_"+kind,a.toString()).apply();}
    private void listData(String kind){JSONArray a=data(kind);if(a.length()==0){TextView empty=text("Nothing here yet. Add your first item to get started.",14,MUTED,false);empty.setPadding(0,10,0,16);body.addView(empty);return;}for(int i=a.length()-1;i>=0;i--){final int idx=i;JSONObject o=a.optJSONObject(i);if(o==null)continue;LinearLayout c=vertical();c.setPadding(15,14,15,14);c.setBackground(round(Color.WHITE,16));String label=o.optString("title",o.optString("type","Item"));if(kind.equals("money"))label=o.optString("type")+" · "+o.optString("amount")+" · "+label;TextView tx=text(label,16,INK,true);c.addView(tx);if(!kind.equals("money")){TextView desc=text(o.optString("detail",o.optBoolean("done")?"Completed":"Tap to manage"),13,MUTED,false);c.addView(desc);}addGap(body,8);body.addView(c);c.setOnClickListener(v->{if(kind.equals("tasks")){try{o.put("done",!o.optBoolean("done"));a.put(idx,o);saveData(kind,a);render();}catch(Exception e){toast("Could not update task");}}else new AlertDialog.Builder(this).setTitle("Delete item?").setMessage("Delete this saved item from this account?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{a.remove(idx);saveData(kind,a);render();}).show();});}}
    private void addItem(String kind){LinearLayout form=vertical();form.setPadding(8,4,8,0);EditText title=field(kind.equals("money")?"Description":"Title");form.addView(title);EditText detail=null,amount=null;Spinner type=null;if(kind.equals("notes")||kind.equals("tasks")){detail=field(kind.equals("notes")?"Note details (optional)":"Details (optional)");form.addView(detail);}if(kind.equals("money")){type=new Spinner(this);String[] opts={"Expense","Income"};type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,opts));form.addView(type);amount=field("Amount");amount.setInputType(8194|4096);form.addView(amount);}final EditText fdetail=detail,famount=amount;final Spinner ftype=type;new AlertDialog.Builder(this).setTitle(kind.equals("tasks")?"New task":kind.equals("notes")?"New note":"New transaction").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String t=title.getText().toString().trim();if(t.isEmpty()){toast("Please enter a title or description");return;}JSONObject o=new JSONObject();try{o.put("title",t);o.put("created",System.currentTimeMillis());if(fdetail!=null)o.put("detail",fdetail.getText().toString());if(kind.equals("tasks"))o.put("done",false);if(kind.equals("money")){double val=Double.parseDouble(famount.getText().toString().trim());if(val<0)throw new Exception();o.put("amount",val);o.put("type",ftype.getSelectedItem().toString());}JSONArray a=data(kind);a.put(o);saveData(kind,a);render();}catch(Exception e){toast("Enter a valid non-negative amount");}}).show();}
    private void gridStat(String label,String value,String sub){LinearLayout c=vertical();c.setPadding(16,15,16,15);c.setBackground(round(Color.WHITE,18));c.addView(text(label,13,MUTED,true));addGap(c,5);c.addView(text(value,25,BLUE,true));c.addView(text(sub,12,MUTED,false));addGap(body,10);body.addView(c);}
    private void section(String s){TextView t=text(s,17,INK,true);t.setPadding(0,4,0,8);body.addView(t);}
    private void action(String s,Runnable r){TextView t=text(s,15,INK,true);t.setPadding(16,15,16,15);t.setBackground(round(Color.WHITE,14));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=8;body.addView(t,lp);t.setOnClickListener(v->r.run());}
    private LinearLayout base(){LinearLayout l=vertical();l.setBackgroundColor(BG);setContentView(l);return l;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setHint(hint);e.setPadding(14,11,14,11);e.setBackground(round(Color.rgb(247,249,253),12));return e;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);b.setTextColor(Color.WHITE);b.setBackground(round(BLUE,14));return b;}
    private android.graphics.drawable.GradientDrawable round(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(radius*getResources().getDisplayMetrics().density);return d;}
    private void addGap(LinearLayout l,int dp){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,(int)(dp*getResources().getDisplayMetrics().density)));}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
